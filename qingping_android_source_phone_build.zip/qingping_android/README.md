# 清屏（QingPing）Android starter

这是一个 Android Studio Kotlin 起始项目，版本 0.1.0。它只尝试识别界面中**完全匹配**的“跳过广告 / Skip ad / Skip”可访问性节点，不使用盲目坐标点击。

## 重要限制
- 这是实验性起始项目，不是已编译、已测试的 APK。
- 无障碍服务必须由用户在系统设置中手动开启。
- 仅能处理目标应用暴露给 Android 无障碍框架的界面节点；WebView、游戏画面、自绘界面、图片按钮等可能无法识别。
- “成功”表示 Android 接受了按钮点击动作，不代表广告一定已消失。
- 本版本按应用包名记录尝试/成功动作；尚未加入应用名称映射、可编辑规则、广告误触分类或复杂的品牌适配。
- 开机广播不会强制启动服务；Android 和手机厂商的后台策略可能停止服务。
- 无障碍权限很敏感。请只安装自己信任并检查过源码的版本，不要用于读取隐私或操控不相关的界面。

## 构建
1. 在安装了 Android SDK 的电脑上，用 Android Studio 打开此目录。
2. 等待 Gradle 同步，安装 Android SDK 35（如提示）。
3. 连接测试手机并运行 `app`，或通过 Android Studio 的 Build 菜单构建 APK。
4. 在手机“设置 → 无障碍”中，手动开启“清屏广告识别服务”。
5. 打开清屏，点“刷新统计”查看本地记录。

## 当前权限
- `BIND_ACCESSIBILITY_SERVICE`：系统绑定无障碍服务的保护权限，不由应用自行授予。
- `RECEIVE_BOOT_COMPLETED`：已声明，但当前版本不会在开机后强行启动服务。
- 未申请 ROOT、悬浮窗、VPN、通讯录、短信或定位权限。


## 仅用手机构建 APK（GitHub Actions）
此项目附带 `.github/workflows/android.yml`，可让 GitHub 云端构建调试版 APK。需要 GitHub 账号和浏览器；这是调试包，不是经过安全审计的正式发布版。

1. 手机上打开 GitHub 网站并登录。
2. 创建一个新的 **Public** 仓库（公开仓库方便按免费额度运行 Actions；不要上传个人隐私或密钥）。仓库名例如 `qingping-android`。
3. 将此 ZIP 解压到手机文件管理器。进入新仓库页面，选择 `Add file` → `Upload files`，上传解压后项目内的所有文件和文件夹，确保 `.github/workflows/android.yml` 也上传。若网页不显示以点开头的 `.github` 文件夹，可改用 GitHub 的网页文件创建功能，按路径新建 `.github/workflows/android.yml` 并粘贴仓库中该文件的内容。
4. 提交到 `main` 分支。进入仓库的 **Actions** 标签页，打开 `Build QingPing APK` 工作流，点 `Run workflow`（若 push 已自动触发则等待它完成）。
5. 构建成功后，打开该次运行页面底部的 **Artifacts**，下载 `qingping-debug-apk`，解压后得到 `app-debug.apk`。
6. 点击 APK 安装。若 Android 提示禁止安装，请只对你使用的浏览器/文件管理器临时允许“安装未知应用”，安装完成后可以关闭该许可。
7. 打开“设置 → 无障碍”，手动开启“清屏广告识别服务”。

如果构建失败，打开 Actions 日志，把错误信息发给助手排查。GitHub 界面名称可能随版本变化。
