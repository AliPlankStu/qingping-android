package com.example.qingping

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            gravity = Gravity.TOP
        }

        val title = TextView(this).apply {
            text = "清屏"
            textSize = 30f
        }
        val desc = TextView(this).apply {
            text = "轻量广告跳过助手（实验版）\\n只尝试点击明确的“跳过广告”按钮，不会盲点屏幕。"
            textSize = 16f
            setPadding(0, 18, 0, 24)
        }
        val enable = Button(this).apply {
            text = "打开无障碍设置"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        summary = TextView(this).apply {
            textSize = 16f
            setPadding(0, 24, 0, 16)
        }
        val refresh = Button(this).apply {
            text = "刷新统计"
            setOnClickListener { updateSummary() }
        }
        val clear = Button(this).apply {
            text = "清空本地统计"
            setOnClickListener {
                getSharedPreferences(AdBlockAccessibilityService.PREFS, MODE_PRIVATE)
                    .edit().clear().apply()
                updateSummary()
            }
        }

        layout.addView(title)
        layout.addView(desc)
        layout.addView(enable)
        layout.addView(summary)
        layout.addView(refresh)
        layout.addView(clear)
        setContentView(layout)
        updateSummary()
    }

    override fun onResume() {
        super.onResume()
        if (::summary.isInitialized) updateSummary()
    }

    private fun updateSummary() {
        val prefs = getSharedPreferences(AdBlockAccessibilityService.PREFS, MODE_PRIVATE)
        val lines = prefs.all.entries
            .filter { it.key.startsWith("success:") || it.key.startsWith("attempt:") }
            .sortedBy { it.key }
            .map { "${it.key.replace("success:", "成功 · ").replace("attempt:", "尝试 · ")}：${it.value}" }
        summary.text = if (lines.isEmpty()) {
            "目前没有记录。开启服务后，使用支持的应用测试。\\n\\n注意：尝试次数不等于广告成功拦截次数。"
        } else {
            "本地统计（按应用包名）：\\n" + lines.joinToString("\\n") +
                "\\n\\n注意：尝试次数不等于广告成功拦截次数。"
        }
    }
}
