package com.example.qingping

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Android does not let an app silently enable its accessibility service.
 * This receiver intentionally does not force-start a background service.
 * The user may need to reopen Accessibility settings after reboot if the
 * device/vendor has disabled the service.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Deliberately no automatic UI launch or background-service start.
        // Accessibility-service state is managed by Android and the user.
    }
}
