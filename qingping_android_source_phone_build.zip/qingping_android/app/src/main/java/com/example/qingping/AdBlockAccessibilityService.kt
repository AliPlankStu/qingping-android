package com.example.qingping

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AdBlockAccessibilityService : AccessibilityService() {
    companion object {
        const val PREFS = "qingping_stats"
        private val TARGET_LABELS = setOf(
            "跳过广告", "跳过广告 >", "跳过广告›",
            "skip ad", "skip ads", "skip"
        )
    }

    private var lastActionAt = 0L
    private var lastPackage = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg.isBlank()) return

        // Only inspect active app windows; do not click based on screen coordinates.
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

        val now = System.currentTimeMillis()
        if (pkg == lastPackage && now - lastActionAt < 1800L) return

        val root = rootInActiveWindow ?: return
        try {
            val target = findExactSkipButton(root) ?: return
            val clicked = target.isClickable &&
                target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (clicked) {
                lastPackage = pkg
                lastActionAt = now
                record(pkg, success = true)
            } else {
                // A visible matching label was found, but a click action was not accepted.
                record(pkg, success = false)
            }
        } finally {
            root.recycle()
        }
    }

    private fun findExactSkipButton(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.trim()?.lowercase()
        val desc = node.contentDescription?.toString()?.trim()?.lowercase()
        val labelMatches = (text != null && text in TARGET_LABELS) ||
            (desc != null && desc in TARGET_LABELS)

        if (labelMatches && node.isVisibleToUser && node.isClickable) {
            return AccessibilityNodeInfo.obtain(node)
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findExactSkipButton(child)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    private fun record(pkg: String, success: Boolean) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val type = if (success) "success:" else "attempt:"
        val editor = prefs.edit()
        val attemptKey = "attempt:" + pkg
        editor.putInt(attemptKey, prefs.getInt(attemptKey, 0) + 1)
        if (success) {
            val successKey = "success:" + pkg
            editor.putInt(successKey, prefs.getInt(successKey, 0) + 1)
        }
        editor.apply()
    }

    override fun onInterrupt() = Unit
}
